NPCLLMChat - AI NPC Conversations

INSTALLATION:
1. Install prerequisites:
   - 0-SCore mod (must match game version)
   - 0-NPCCore mod
   - Ollama (ollama.com)
   - Python 3.9+ (python.org)

2. Extract this entire NPCLLMChat folder to:
   <Game>\Mods\NPCLLMChat\

3. Run setup_servers.bat (one time only):
   cd Mods\NPCLLMChat
   setup_servers.bat

4. Download AI model:
   ollama pull gemma3:4b

5. Launch game and talk to NPCs!
   - Text: @Hello
   - Voice: Hold V key
